# ValentinesDay
Inspired by: https://valentine.mewtru.com
![image](https://github.com/shacowka6on/ValentinesDay/assets/92218265/2090c5b6-2f34-48ee-9c4c-dae0c060e4c6)
After pressing "No" a couple times
![image](https://github.com/shacowka6on/ValentinesDay/assets/92218265/a29dc337-a561-47a9-9eb1-86d5348af7eb)
And after pressing "Yes"
![image](https://github.com/shacowka6on/ValentinesDay/assets/92218265/8d7520a4-40ae-4801-a3e0-7351a28535a5)

